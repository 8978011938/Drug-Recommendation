import pickle
import streamlit as st
from streamlit_option_menu import option_menu

# app.py
import streamlit as st
from sklearn.externals import joblib

# Load the trained machine learning model
model = joblib.load('path_to_your_model.pkl')

def drug_recommendation(features):
    # Make a prediction using the trained model
    prediction = model.predict([features])
    return prediction[0]

def main():
    st.title("Drug Recommendation System")

    # Collect user input
    feature1 = st.slider("Feature 1", min_value=0.0, max_value=10.0, step=0.1)
    feature2 = st.slider("Feature 2", min_value=0.0, max_value=10.0, step=0.1)
    # Add more input fields as needed

    if st.button("Get Recommendation"):
        # Create a feature vector from user input
        input_data = [feature1, feature2]  # Add more features as needed

        # Get drug recommendation
        recommendation = drug_recommendation(input_data)

        # Display the result
        st.success(f"The recommended drug is: {recommendation}")

if __name__ == "__main__":
    main()



if st.button("About"):
        st.text("Lets LEarn")
        st.text("Built with Streamlit")